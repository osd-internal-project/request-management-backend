# Changelog


## 0.13.0 (2026-01-19)

* [keycloak]: Add simultaneous support for http and https (#863) ([bb671a5](https://github.com/CloudPirates-io/helm-charts/commit/bb671a5))
* chore: update CHANGELOG.md for merged changes ([5d467af](https://github.com/CloudPirates-io/helm-charts/commit/5d467af))
* chore: update CHANGELOG.md for merged changes ([a1b890a](https://github.com/CloudPirates-io/helm-charts/commit/a1b890a))

## 0.12.0 (2026-01-19)

* [keycloak]: Move to stateful set (#859) ([76ed920](https://github.com/CloudPirates-io/helm-charts/commit/76ed920))
* chore: update CHANGELOG.md for merged changes ([2c2a6dd](https://github.com/CloudPirates-io/helm-charts/commit/2c2a6dd))
* chore: update CHANGELOG.md for merged changes ([d32e3a8](https://github.com/CloudPirates-io/helm-charts/commit/d32e3a8))
* chore: update CHANGELOG.md for merged changes ([3b399af](https://github.com/CloudPirates-io/helm-charts/commit/3b399af))

## 0.11.5 (2026-01-19)

* [keycloak/keycloak] Update charts/keycloak/values.yaml keycloak/keycloak to v26.5.1 (patch) (#860) ([8b8713d](https://github.com/CloudPirates-io/helm-charts/commit/8b8713d))
* chore: update CHANGELOG.md for merged changes ([2b47b4b](https://github.com/CloudPirates-io/helm-charts/commit/2b47b4b))
* chore: update CHANGELOG.md for merged changes ([f764d87](https://github.com/CloudPirates-io/helm-charts/commit/f764d87))
* chore: update CHANGELOG.md for merged changes ([de14f91](https://github.com/CloudPirates-io/helm-charts/commit/de14f91))

## 0.11.4 (2026-01-08)

* [keycloak/keycloak] Update charts/keycloak/values.yaml keycloak/keycloak to v26.5.0 (minor) (#823) ([7e1eb1c](https://github.com/CloudPirates-io/helm-charts/commit/7e1eb1c))

## 0.11.3 (2025-12-04)

* chore: update CHANGELOG.md for merged changes ([f9db9cb](https://github.com/CloudPirates-io/helm-charts/commit/f9db9cb))
* chore: update CHANGELOG.md for merged changes ([b310b06](https://github.com/CloudPirates-io/helm-charts/commit/b310b06))
* Apply preserveThemes and preserveProviders to the deployment for volume mounts (#689) ([58d54a8](https://github.com/CloudPirates-io/helm-charts/commit/58d54a8))

## 0.11.2 (2025-12-01)

* chore: update CHANGELOG.md for merged changes ([5bef5a3](https://github.com/CloudPirates-io/helm-charts/commit/5bef5a3))
* quote dnsnames for certificates (#678) ([1dde1f7](https://github.com/CloudPirates-io/helm-charts/commit/1dde1f7))

## 0.11.1 (2025-12-01)

* chore: update CHANGELOG.md for merged changes ([5ead46d](https://github.com/CloudPirates-io/helm-charts/commit/5ead46d))
* chore: update CHANGELOG.md for merged changes ([5428a9d](https://github.com/CloudPirates-io/helm-charts/commit/5428a9d))
* [keycloak/keycloak] Update charts/keycloak/values.yaml keycloak/keycloak to v26.4.7 (patch) (#664) ([3224ae7](https://github.com/CloudPirates-io/helm-charts/commit/3224ae7))

## 0.11.0 (2025-11-26)

* chore: update CHANGELOG.md for merged changes ([b4e5184](https://github.com/CloudPirates-io/helm-charts/commit/b4e5184))
* chore: update CHANGELOG.md for merged changes ([84cd609](https://github.com/CloudPirates-io/helm-charts/commit/84cd609))
* Fix/allow realm import on production mode (#668) ([be3939e](https://github.com/CloudPirates-io/helm-charts/commit/be3939e))
* chore: update CHANGELOG.md for merged changes ([bdc9c44](https://github.com/CloudPirates-io/helm-charts/commit/bdc9c44))
* chore: update CHANGELOG.md for merged changes ([79f87c5](https://github.com/CloudPirates-io/helm-charts/commit/79f87c5))

## 0.10.2 (2025-11-26)

* chore: update CHANGELOG.md for merged changes ([3191aa5](https://github.com/CloudPirates-io/helm-charts/commit/3191aa5))
* Use correct metrics path if httpRelativePath is set (#666) ([87276ae](https://github.com/CloudPirates-io/helm-charts/commit/87276ae))

## 0.10.1 (2025-11-26)

* chore: update CHANGELOG.md for merged changes ([0ff63ff](https://github.com/CloudPirates-io/helm-charts/commit/0ff63ff))
* chore: update CHANGELOG.md for merged changes ([b7aabd2](https://github.com/CloudPirates-io/helm-charts/commit/b7aabd2))
* Preserve themes and providers options (#660) ([1bf70b4](https://github.com/CloudPirates-io/helm-charts/commit/1bf70b4))

## 0.10.0 (2025-11-25)

* chore: update CHANGELOG.md for merged changes ([723bd23](https://github.com/CloudPirates-io/helm-charts/commit/723bd23))
* chore: update CHANGELOG.md for merged changes ([786bcaf](https://github.com/CloudPirates-io/helm-charts/commit/786bcaf))
* Add support for PriorityClass (#651) ([0aaf369](https://github.com/CloudPirates-io/helm-charts/commit/0aaf369))

## 0.9.1 (2025-11-24)

* chore: update CHANGELOG.md for merged changes ([fe5d8ec](https://github.com/CloudPirates-io/helm-charts/commit/fe5d8ec))
* chore: update CHANGELOG.md for merged changes ([6ad9df0](https://github.com/CloudPirates-io/helm-charts/commit/6ad9df0))
* [Keycloak[ improve subchart variables (#652) ([e1c50c6](https://github.com/CloudPirates-io/helm-charts/commit/e1c50c6))

## 0.9.0 (2025-11-24)

* chore: update CHANGELOG.md for merged changes ([56c82a4](https://github.com/CloudPirates-io/helm-charts/commit/56c82a4))
* chore: update CHANGELOG.md for merged changes ([6a0f6d4](https://github.com/CloudPirates-io/helm-charts/commit/6a0f6d4))
* Keycloak/subchart variables (#649) ([bb0520a](https://github.com/CloudPirates-io/helm-charts/commit/bb0520a))

## 0.8.8 (2025-11-24)

* chore: update CHANGELOG.md for merged changes ([1e61a3e](https://github.com/CloudPirates-io/helm-charts/commit/1e61a3e))
* chore: update CHANGELOG.md for merged changes ([768186e](https://github.com/CloudPirates-io/helm-charts/commit/768186e))
* Fix JDBC connection string when using mssql database (#643) (#644) ([639db93](https://github.com/CloudPirates-io/helm-charts/commit/639db93))
* chore: update CHANGELOG.md for merged changes ([266b5f5](https://github.com/CloudPirates-io/helm-charts/commit/266b5f5))
* fix: correct installation command in the  (#646) ([b88029b](https://github.com/CloudPirates-io/helm-charts/commit/b88029b))

## 0.8.7 (2025-11-22)

* chore: update CHANGELOG.md for merged changes ([61c0c0c](https://github.com/CloudPirates-io/helm-charts/commit/61c0c0c))
* chore: update CHANGELOG.md for merged changes ([b810690](https://github.com/CloudPirates-io/helm-charts/commit/b810690))
* Make resources apply to initContainers (#645) ([35f4ac3](https://github.com/CloudPirates-io/helm-charts/commit/35f4ac3))

## 0.8.6 (2025-11-13)

* chore: update CHANGELOG.md for merged changes ([9c2e3e2](https://github.com/CloudPirates-io/helm-charts/commit/9c2e3e2))
* chore: update CHANGELOG.md for merged changes ([2e45ccd](https://github.com/CloudPirates-io/helm-charts/commit/2e45ccd))
* [keycloak/keycloak] Update charts/keycloak/values.yaml keycloak/keycloak to v26.4.5 (patch) (#593) ([a4cfe0c](https://github.com/CloudPirates-io/helm-charts/commit/a4cfe0c))
* chore: update CHANGELOG.md for merged changes ([96c472e](https://github.com/CloudPirates-io/helm-charts/commit/96c472e))
* chore: update CHANGELOG.md for merged changes ([9923048](https://github.com/CloudPirates-io/helm-charts/commit/9923048))

## 0.8.5 (2025-11-13)

* chore: update CHANGELOG.md for merged changes ([09bffff](https://github.com/CloudPirates-io/helm-charts/commit/09bffff))
* chore: update CHANGELOG.md for merged changes ([f48bb48](https://github.com/CloudPirates-io/helm-charts/commit/f48bb48))

## 0.8.4 (2025-11-11)

* [keycloak/keycloak] Update charts/keycloak/values.yaml keycloak/keycloak to v26.4.4 (patch) (#563) ([c65d420](https://github.com/CloudPirates-io/helm-charts/commit/c65d420))
* chore: update CHANGELOG.md for merged changes ([5797494](https://github.com/CloudPirates-io/helm-charts/commit/5797494))
* chore: update CHANGELOG.md for merged changes ([1a445f9](https://github.com/CloudPirates-io/helm-charts/commit/1a445f9))
* chore: auto-generate values.schema.json (#578) ([584a535](https://github.com/CloudPirates-io/helm-charts/commit/584a535))
* chore: update CHANGELOG.md for merged changes ([69f290f](https://github.com/CloudPirates-io/helm-charts/commit/69f290f))
* chore: update CHANGELOG.md for merged changes ([7b32772](https://github.com/CloudPirates-io/helm-charts/commit/7b32772))

## 0.8.3 (2025-11-11)

* add truststoreExistingSecretKey, add truststorePassword to env-Vars (#574) ([9c97080](https://github.com/CloudPirates-io/helm-charts/commit/9c97080))
* chore: update CHANGELOG.md for merged changes ([e67a635](https://github.com/CloudPirates-io/helm-charts/commit/e67a635))
* chore: update CHANGELOG.md for merged changes ([607f120](https://github.com/CloudPirates-io/helm-charts/commit/607f120))

## 0.8.2 (2025-11-05)

* [keycloak]: Fix mariadb configuration (#544) ([6cec40c](https://github.com/CloudPirates-io/helm-charts/commit/6cec40c))
* chore: update CHANGELOG.md for merged changes ([72853a9](https://github.com/CloudPirates-io/helm-charts/commit/72853a9))
* chore: update CHANGELOG.md for merged changes ([cd5cd19](https://github.com/CloudPirates-io/helm-charts/commit/cd5cd19))

## 0.8.1 (2025-11-02)

* [keycloak]: Fix https settings in keycloak when disabling http (#530) ([b0c34f6](https://github.com/CloudPirates-io/helm-charts/commit/b0c34f6))
* chore: update CHANGELOG.md for merged changes ([3062545](https://github.com/CloudPirates-io/helm-charts/commit/3062545))
* chore: update CHANGELOG.md for merged changes ([19b8107](https://github.com/CloudPirates-io/helm-charts/commit/19b8107))

## 0.8.0 (2025-10-30)

* Provide empty mounts for themes and providers (#504) ([4d2f107](https://github.com/CloudPirates-io/helm-charts/commit/4d2f107))
* chore: update CHANGELOG.md for merged changes ([385f22b](https://github.com/CloudPirates-io/helm-charts/commit/385f22b))
* chore: update CHANGELOG.md for merged changes ([488fba4](https://github.com/CloudPirates-io/helm-charts/commit/488fba4))

## 0.7.1 (2025-10-29)

* fix: use metrics service targetPort configuration (#493) ([bd3cc53](https://github.com/CloudPirates-io/helm-charts/commit/bd3cc53))
* chore: update CHANGELOG.md for merged changes ([8260788](https://github.com/CloudPirates-io/helm-charts/commit/8260788))
* chore: update CHANGELOG.md for merged changes ([402f7bd](https://github.com/CloudPirates-io/helm-charts/commit/402f7bd))

## 0.7.0 (2025-10-28)

* chore: update CHANGELOG.md for merged changes ([aec2fd6](https://github.com/CloudPirates-io/helm-charts/commit/aec2fd6))
* chore: update CHANGELOG.md for merged changes ([8e4ff4a](https://github.com/CloudPirates-io/helm-charts/commit/8e4ff4a))
* chore: auto-generate values.schema.json (#473) ([d9a38d4](https://github.com/CloudPirates-io/helm-charts/commit/d9a38d4))
* chore: update CHANGELOG.md for merged changes ([293ae00](https://github.com/CloudPirates-io/helm-charts/commit/293ae00))
* chore: update CHANGELOG.md for merged changes ([ae9c37b](https://github.com/CloudPirates-io/helm-charts/commit/ae9c37b))

## 0.6.8 (2025-10-27)

* add mssql support (#469) ([11cdbfb](https://github.com/CloudPirates-io/helm-charts/commit/11cdbfb))
* chore: update CHANGELOG.md for merged changes ([6813d85](https://github.com/CloudPirates-io/helm-charts/commit/6813d85))
* chore: update CHANGELOG.md for merged changes ([2e40f13](https://github.com/CloudPirates-io/helm-charts/commit/2e40f13))

## 0.6.7 (2025-10-26)

* [keycloak/keycloak] Update charts/keycloak/values.yaml keycloak/keycloak to v26.4.2 (patch) (#453) ([52a01c8](https://github.com/CloudPirates-io/helm-charts/commit/52a01c8))
* chore: update CHANGELOG.md for merged changes ([f9c3ff0](https://github.com/CloudPirates-io/helm-charts/commit/f9c3ff0))
* chore: update CHANGELOG.md for merged changes ([db2d800](https://github.com/CloudPirates-io/helm-charts/commit/db2d800))

## 0.6.6 (2025-10-23)

* chore: update CHANGELOG.md for merged changes ([051ad83](https://github.com/CloudPirates-io/helm-charts/commit/051ad83))
* chore: update CHANGELOG.md for merged changes ([1a50307](https://github.com/CloudPirates-io/helm-charts/commit/1a50307))

## 0.6.5 (2025-10-22)

* chore: update CHANGELOG.md for merged changes ([c80ea42](https://github.com/CloudPirates-io/helm-charts/commit/c80ea42))
* chore: update CHANGELOG.md for merged changes ([8ccb4bb](https://github.com/CloudPirates-io/helm-charts/commit/8ccb4bb))
* chore: update CHANGELOG.md for merged changes ([5d1f01a](https://github.com/CloudPirates-io/helm-charts/commit/5d1f01a))
* chore: update CHANGELOG.md for merged changes ([fc47c5d](https://github.com/CloudPirates-io/helm-charts/commit/fc47c5d))
* chore: update CHANGELOG.md for merged changes ([1a4f87b](https://github.com/CloudPirates-io/helm-charts/commit/1a4f87b))
* chore: update CHANGELOG.md for merged changes ([da866ca](https://github.com/CloudPirates-io/helm-charts/commit/da866ca))
* chore: update CHANGELOG.md for merged changes ([b06a24e](https://github.com/CloudPirates-io/helm-charts/commit/b06a24e))
* chore: update CHANGELOG.md for merged changes ([b70f02c](https://github.com/CloudPirates-io/helm-charts/commit/b70f02c))
* chore: update CHANGELOG.md for merged changes ([94c7881](https://github.com/CloudPirates-io/helm-charts/commit/94c7881))

## 0.6.4 (2025-10-17)

* realm import (#402) ([4257b8b](https://github.com/CloudPirates-io/helm-charts/commit/4257b8b))
* chore: update CHANGELOG.md for merged changes ([1184994](https://github.com/CloudPirates-io/helm-charts/commit/1184994))
* chore: update CHANGELOG.md for merged changes ([8b0e613](https://github.com/CloudPirates-io/helm-charts/commit/8b0e613))

## 0.6.3 (2025-10-17)

* [keycloak/keycloak] Update charts/keycloak/values.yaml keycloak/keycloak to v26.4.1 (patch) (#400) ([c6f2ca2](https://github.com/CloudPirates-io/helm-charts/commit/c6f2ca2))
* chore: update CHANGELOG.md for merged changes ([b54c4f1](https://github.com/CloudPirates-io/helm-charts/commit/b54c4f1))
* chore: update CHANGELOG.md for merged changes ([5a2ed20](https://github.com/CloudPirates-io/helm-charts/commit/5a2ed20))
* chore: update CHANGELOG.md for merged changes ([48c9191](https://github.com/CloudPirates-io/helm-charts/commit/48c9191))
* chore: update CHANGELOG.md for merged changes ([46b32bf](https://github.com/CloudPirates-io/helm-charts/commit/46b32bf))

## 0.6.2 (2025-10-14)

* Add support for templating hostname and hostnameAdmin (#390) ([133f4d5](https://github.com/CloudPirates-io/helm-charts/commit/133f4d5))
* chore: update CHANGELOG.md for merged changes ([848e965](https://github.com/CloudPirates-io/helm-charts/commit/848e965))
* chore: update CHANGELOG.md for merged changes ([353c0fc](https://github.com/CloudPirates-io/helm-charts/commit/353c0fc))

## 0.6.1 (2025-10-14)

* [keycloak]: Implement TLS in keycloak (#373) ([04abaee](https://github.com/CloudPirates-io/helm-charts/commit/04abaee))
* chore: update CHANGELOG.md for merged changes ([4b02e57](https://github.com/CloudPirates-io/helm-charts/commit/4b02e57))
* chore: update CHANGELOG.md for merged changes ([bf2e3b2](https://github.com/CloudPirates-io/helm-charts/commit/bf2e3b2))
* chore: update CHANGELOG.md for merged changes ([2f87d0e](https://github.com/CloudPirates-io/helm-charts/commit/2f87d0e))

## 0.6.0 (2025-10-14)

* chore: update CHANGELOG.md for merged changes ([84cf67b](https://github.com/CloudPirates-io/helm-charts/commit/84cf67b))
* chore: update CHANGELOG.md for all charts via manual trigger ([6974964](https://github.com/CloudPirates-io/helm-charts/commit/6974964))
* chore: update CHANGELOG.md for merged changes ([63b7bfa](https://github.com/CloudPirates-io/helm-charts/commit/63b7bfa))
* chore: update CHANGELOG.md for merged changes ([da69e0e](https://github.com/CloudPirates-io/helm-charts/commit/da69e0e))
* chore: update CHANGELOG.md for merged changes ([5da1b15](https://github.com/CloudPirates-io/helm-charts/commit/5da1b15))

## 0.5.1 (2025-10-13)

* chore: update CHANGELOG.md for merged changes ([a67d12a](https://github.com/CloudPirates-io/helm-charts/commit/a67d12a))
* chore: update CHANGELOG.md for merged changes ([a4bd5ac](https://github.com/CloudPirates-io/helm-charts/commit/a4bd5ac))

## 0.5.0 (2025-10-13)

* feat: add metrics (#368) ([cf5aba0](https://github.com/CloudPirates-io/helm-charts/commit/cf5aba0))

## 0.4.0 (2025-10-10)

* Import realm (#219) ([f7ff0cf](https://github.com/CloudPirates-io/helm-charts/commit/f7ff0cf))
* add tests for openshift (#226) ([c80c98a](https://github.com/CloudPirates-io/helm-charts/commit/c80c98a))
* [keycloak]: Fix invalid documentation (#283) ([59f3d3c](https://github.com/CloudPirates-io/helm-charts/commit/59f3d3c))

## 0.3.2 (2025-10-09)

* [keycloak/keycloak] Update charts/keycloak/values.yaml keycloak/keycloak to v26.4.0 (minor) (#270) ([b107e1b](https://github.com/CloudPirates-io/helm-charts/commit/b107e1b))

## 0.3.1 (2025-10-09)

* [keycloak/keycloak] Update charts/keycloak/values.yaml keycloak/keycloak to v26.3.5 (patch) (#261) ([360de40](https://github.com/CloudPirates-io/helm-charts/commit/360de40))

## 0.3.0 (2025-10-08)

* make keycloak run on openshift (#225) ([9b4f896](https://github.com/CloudPirates-io/helm-charts/commit/9b4f896))

## 0.2.1 (2025-10-07)

* default http relative path to '/' to fix argocd deployment (#221) ([bdb1946](https://github.com/CloudPirates-io/helm-charts/commit/bdb1946))

## 0.2.0 (2025-10-06)

* Add support for extra volumes, volumeMounts and initContainers (#215) ([16afcfe](https://github.com/CloudPirates-io/helm-charts/commit/16afcfe))

## 0.1.12 (2025-10-06)


## 0.1.11 (2025-10-06)

* Allow keycloak to have a relative path (#216) ([0237457](https://github.com/CloudPirates-io/helm-charts/commit/0237457))

## 0.1.10 (2025-10-02)


## 0.1.9 (2025-10-02)

* add topologySpreadConstraints and trafficDistribution opti… (#209) ([c777fca](https://github.com/CloudPirates-io/helm-charts/commit/c777fca))

## 0.1.8 (2025-09-30)

* Feature/command customize (#186) ([a458e15](https://github.com/CloudPirates-io/helm-charts/commit/a458e15))

## 0.1.7 (2025-09-29)

* replace deprecated 'proxy' with new proxy parameters (#183) ([d850b7b](https://github.com/CloudPirates-io/helm-charts/commit/d850b7b))

## 0.1.6 (2025-09-26)


## 0.1.5 (2025-09-25)

* add support for extra env vars from an existing secret (#158) ([263604f](https://github.com/CloudPirates-io/helm-charts/commit/263604f))
* Update CHANGELOG.md ([b7572a8](https://github.com/CloudPirates-io/helm-charts/commit/b7572a8))
* Update CHANGELOG.md ([245f9b6](https://github.com/CloudPirates-io/helm-charts/commit/245f9b6))
* Update CHANGELOG.md ([0bf9f75](https://github.com/CloudPirates-io/helm-charts/commit/0bf9f75))

## 0.1.4 (2025-09-24)

* Update CHANGELOG.md ([03d476e](https://github.com/CloudPirates-io/helm-charts/commit/03d476e))
* Bump the correct thing ([35e7901](https://github.com/CloudPirates-io/helm-charts/commit/35e7901))
* Update CHANGELOG.md ([20c19bb](https://github.com/CloudPirates-io/helm-charts/commit/20c19bb))

## 0.1.3 (2025-09-23)

* Update CHANGELOG.md ([68435aa](https://github.com/CloudPirates-io/helm-charts/commit/68435aa))
* Fix resolving template expressions in extraobjects ([12a1cb5](https://github.com/CloudPirates-io/helm-charts/commit/12a1cb5))

## 0.1.2 (2025-09-22)

* Update CHANGELOG.md ([b8adca8](https://github.com/CloudPirates-io/helm-charts/commit/b8adca8))
* Fix chart version bump ([aae07b1](https://github.com/CloudPirates-io/helm-charts/commit/aae07b1))
* Fix deprecated env vars warning ([50d9fa0](https://github.com/CloudPirates-io/helm-charts/commit/50d9fa0))

## 0.1.1 (2025-09-19)

* Update CHANGELOG.md ([62e51b9](https://github.com/CloudPirates-io/helm-charts/commit/62e51b9))
* add readme documentation and values.schema.json ([369448b](https://github.com/CloudPirates-io/helm-charts/commit/369448b))
* Update CHANGELOG.md ([54f725e](https://github.com/CloudPirates-io/helm-charts/commit/54f725e))
* chore: fix changelog ([bd9f1a8](https://github.com/CloudPirates-io/helm-charts/commit/bd9f1a8))
* Update CHANGELOG.md ([2ed9b3f](https://github.com/CloudPirates-io/helm-charts/commit/2ed9b3f))
* Update CHANGELOG.md ([2178148](https://github.com/CloudPirates-io/helm-charts/commit/2178148))

## 0.1.0 (2025-09-17)

* Initial tagged release
